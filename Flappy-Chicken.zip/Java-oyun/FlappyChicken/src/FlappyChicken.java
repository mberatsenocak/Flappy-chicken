import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

import javax.management.StringValueExp;
import javax.swing.*;


public class FlappyChicken extends JPanel implements ActionListener, KeyListener {
    int boardWidth = 360;
    int boardHeight = 640;

    //Images - Bu dört değişken resim nesnelerimizi depolayacak
    Image backgroundImg;
    Image chickenImg;
    Image topPipeImg;
    Image bottomPipeImg;

    //Chicken
    int chickenX = boardWidth/8;
    int chickenY = boardHeight/2;
    int chickenWidth = 54;//34
    int chickenHeight = 44;//24

    class Chicken{
        int x = chickenX;
        int y = chickenY;
        int width = chickenWidth;
        int height = chickenHeight;
        Image img;

        Chicken(Image img){
            this.img = img;
        }
    }

    //pipes
    int pipeX = boardWidth;
    int pipeY = 0;
    int pipeWidth = 64;  //scaled 1/6
    int pipeHeight = 512;

    class Pipe{
        int x = pipeX;
        int y = pipeY;
        int width = pipeWidth;
        int height = pipeHeight;
        Image img;
        boolean passed = false;

        Pipe(Image img){
            this.img = img;
        }
        
    }



    //Game logic
    Chicken chicken;   
    int velocityX = -4;   //Boruların sola doğru hareketi (kuşun sağa doğru hareketi)
    int velocityY = 0;
    int gravity = 1;
    
    ArrayList<Pipe> pipes; //Borular sürekli değişeceği için bir dizi oluşturuyoruz 
    Random random = new Random(); //Yeni bir rastgelelik nesnesi oluşturuyoruz

    Timer gameLoop;
    Timer placePipesTimer;
    boolean GameOver = false;
    double score = 0;


    FlappyChicken() {
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        //setBackground(Color.blue);
        setFocusable(true);
        addKeyListener(this);

        //load images 
        backgroundImg = new ImageIcon(getClass().getResource("./flappybirdbg.png")).getImage();
        chickenImg = new ImageIcon(getClass().getResource("./ChickenFlappy.png")).getImage();
        topPipeImg = new ImageIcon(getClass().getResource("./toppipe.png")).getImage();
        bottomPipeImg = new ImageIcon(getClass().getResource("./bottompipe.png")).getImage();

        //Chicken
        chicken = new Chicken(chickenImg);
        pipes = new ArrayList<Pipe>();

        //Place pipes Timer
        placePipesTimer = new Timer(1500, new ActionListener(){
          
            @Override
            public void actionPerformed(ActionEvent e){ //Bu metot her 1.5 saniyede bir çalışacak
                placePipes();
            }
        });
        placePipesTimer.start();

        //Game timer
        gameLoop = new Timer(1000/60, this); //Saniyede 60 karde gösterir 1000/60 = 16,6
        gameLoop.start(); //Döngüyü başlatıyoruz
    
    }

    public void placePipes(){
        //Burada math.random bize rastgele bir sayı döndürecek ve pipeHeight/2 ile sayfanın yarısı arasında bir sayı olacak

        int randomPipeY = (int) (pipeY - pipeHeight/4 - Math.random()*pipeHeight/2);  //Boruların yüksekliği rastgele olacak
        int openingSpace = boardHeight/4; //Borular arasındaki boşluk

        Pipe topPipe = new Pipe (topPipeImg);
        topPipe.y = randomPipeY;
        pipes.add(topPipe);

        Pipe bottomPipe = new Pipe(bottomPipeImg);
        bottomPipe.y = topPipe.y + pipeHeight + openingSpace; 
        pipes.add(bottomPipe);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        //Background
        g.drawImage(backgroundImg, 0, 0, boardWidth, boardHeight, null); //Burası arkaplanın sol üst köşesi
    
        //Chicken 
        g.drawImage(chickenImg, chicken.x, chicken.y, chickenWidth, chickenHeight, null);

        //Pipes
        for(int i = 0; i<pipes.size(); i++){
            Pipe pipe = pipes.get(i);
            g.drawImage(pipe.img, pipe.x, pipe.y, pipeWidth, pipeHeight, null);
        };

        //Score
        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.PLAIN, 32));
        if(GameOver){
            g.drawString("Game Over: " + String.valueOf((int)score), 10, 35);
        }
        else{
            g.drawString(String.valueOf((int)score), 10, 35);
        }
    }

    public void move(){
        //chicken
        velocityY += gravity;
        chicken.y += velocityY;
        chicken.y = Math.max(chicken.y, 0);

        //pipes
        for(int i = 0; i<pipes.size(); i++){
            Pipe pipe = pipes.get(i);
            pipe.x += velocityX;

            if(!pipe.passed && chicken.x > pipe.x + pipe.width)

            {
                pipe.passed = true;
                score += 0.5; // Her boruyu geçtiğinde skoru 0.5 arttırır
            }

            if (collision(chicken, pipe)){
                GameOver = true;
            } 
        }

        if(chicken.y > boardHeight) {
            GameOver = true;   
        }   
    
    }
    
    
    public boolean collision (Chicken a, Pipe b){ //Tavuğun borulara çarptığında vereceği tepki
        return a.x < b.x + b.width && // A'nın sol üst köşesi B'nin sağ üst köşesine eşit veya daha küçükse
         a.x + a.width > b.x && // A'nın sağ üst köşesi B'nin sol üst köşesine eşit veya daha büyükse
          a.y < b.y + b.height && // A'nın sol alt köşesi B'nin sağ alt köşesine eşit veya daha küçükse
           a.y + a.height > b.y; // A'nın sağ alt köşesi B'nin sol alt köşesine eşit veya daha büyükse
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        move();
        repaint();
        if(GameOver){
            placePipesTimer.stop();
            gameLoop.stop();
        }
    }



    @Override
    public void keyPressed(KeyEvent e) {
      if(e.getKeyCode() == KeyEvent.VK_SPACE){
          velocityY = -9;
          if(GameOver){
            //Restart game
            chicken.y = chickenY;
            velocityY = 0;
            pipes.clear();
            score = 0;
            GameOver = false;
            gameLoop.start();
            placePipesTimer.start();
          }
      }
        
    }
  
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}
